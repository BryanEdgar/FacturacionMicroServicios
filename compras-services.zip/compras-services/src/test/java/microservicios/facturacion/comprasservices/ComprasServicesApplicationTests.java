package microservicios.facturacion.comprasservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComprasServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
