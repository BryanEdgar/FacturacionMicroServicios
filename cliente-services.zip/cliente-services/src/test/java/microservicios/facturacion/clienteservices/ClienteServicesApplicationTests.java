package microservicios.facturacion.clienteservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
