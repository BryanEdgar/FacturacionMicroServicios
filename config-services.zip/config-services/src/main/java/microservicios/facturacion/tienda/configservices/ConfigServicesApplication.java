package microservicios.facturacion.tienda.configservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigServicesApplication.class, args);
	}

}
