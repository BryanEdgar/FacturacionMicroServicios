package microservicios.facturacion.tienda.configservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
