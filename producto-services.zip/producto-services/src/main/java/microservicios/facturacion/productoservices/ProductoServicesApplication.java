package microservicios.facturacion.productoservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductoServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductoServicesApplication.class, args);
	}

}
