package microservicios.facturacion.productoservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
